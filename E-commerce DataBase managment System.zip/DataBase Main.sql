create table customer(
customer_id int primary key,
FirstName Varchar(50),
LastName Varchar(50),
Email varchar(50));

create table seller(
seller_id int primary key,
company_name varchar(50),
phone_number varchar(50) );


create table product(
product_id int primary key,
product_name varchar(50),
price decimal(10,2),
descriptions text,
seller_id int,
foreign key (seller_id) references seller(seller_id));


create table orders(
order_id int primary key,
order_date date,
order_amount varchar(50),
customer_id int,
foreign key(customer_id) references customer(customer_id));

create table order_item(

order_item_id int primary key,
quantity int ,
order_id int,
product_id int,
foreign key (order_id) references orders(order_id),
foreign key (product_id) references product(product_id));


create table payments(

payment_id int primary key,
amount decimal(10,3),
payment_date date,
customer_id int,
order_id int ,
foreign key(customer_id) references customer(customer_id),
foreign key(order_id) references orders(order_id));

insert into customer(customer_id,FirstName,LastName,Email)
       values(1010,'Alemu','Belte','Alemubelete09@gmail.com'),
	         (1015,'Esuablew','Teka','EsubalewTeka98@gmail.com'),
			 (1020,'Teshome','Negatu','TeshomeNegatu76@gmail.com'),
	         (1030,'Tomas','Kebede','TomasKebede78@gmail.com'),
	         (1040,'Yared','Abebe','YaredAbebe67@gmail.com');


insert into seller(seller_id,company_name,phone_number)
	   values(201,'Thread','0331117665'),
			 (202,'Bloomingdale','0331114565'),
			 (203,'Blacktower','0331124565'),
			 (204,'ombre','0331114521'),
			 (205,'Central','0331117632');


insert into product(product_id,product_name,price,descriptions,seller_id)
       values(11110,'sketchers',200,'comfy and light shoes',0201),
			 (11111,'sweats',140,'suitable wears for all weather types',0202),
			 (11112,'Cables',100,'recommend for hardware wiring purposes',0203),
			 (11113,'perfume',300,'Nice odour through out the day',0204),
			 (11114,' office Furnitures',400,'suitable office products',0205);

insert into  orders(order_id,order_date,order_amount,customer_id)
	   values(1221,'2016-06-09',2,1010),
	         (1331,'2016-06-02',1,1015),
			 (1441,'2016-06-13',3,1020),
			 (1551,'2016-06-18',4,1030),
			 (1661,'2016-06-27',1,1040);


insert into order_item(order_item_id,quantity,order_id,product_id)
      values(9898,15,1221,11110),
			(8787,20,1331,11111),
			(7676,13,1441,11112),
			(6565,15,1551,11113),
			(5454,8,1661,11114);

insert into payments(payment_id,amount,payment_date,customer_id,order_id)
       values(10,354.30,'2016-10-09',1010,1221),
	         (20,200,'2016-08-10',1015,1331),
			 (30,400,'2016-12-01',1020,1441),
			 (40,150.5,'2016-05-12',1030,1551),
			 (50,200,'2016-03-01',1040,1661);

			 
---DELETING A CUSTOMER
delete from customer where customer_id = 1030;

---DELETING A PRODUCT
delete from product where price =100;

--updating customer table 
update customer set Email = 'NegatuTeshome000@gmail.com' where customer_id = 1020;
update customer set FirstName = 'Markos' where LastName = 'Teka';

--Updating product table
update product set price = 170 where product_name = 'cables';

--select
select *from customer;
select *from orders;
select *from payments;
select *from seller;
select *from order_item;
select *from product;

--drop  table
drop table orders;

--Altering a table
alter table customer add phone_number int;
alter table seller add email_address varchar(50);
go

-- creating a view1
create view payment_view as
select payment_id,amount from payments 
go
select *from payment_view;

--creating view 2
go
CREATE VIEW OrderDetailsView AS
SELECT
    o.order_id,
    o.order_date,
    c.FirstName AS customer_first_name,
    c.LastName AS customer_last_name,
    p.product_name,
    p.price AS product_price,
    oi.quantity AS product_quantity,
    oi.quantity * p.price AS total_price
FROM
    orders o

INNER JOIN customer c ON o.customer_id = c.customer_id
INNER JOIN order_item oi ON o.order_id = oi.order_id
INNER JOIN product p ON oi.product_id = p.product_id;
go

SELECT * FROM OrderDetailsView 
order by order_id asc
go
drop view OrderDetailsView

--creating view 3
create view product_view as 
select product_name,price from product
go
select *from product_view;
go

--deleting view 
drop view product_view
go

--creating user defined function
CREATE FUNCTION CalculateOrderTotalPrice (@orderID int)
RETURNS decimal(10,2)
AS
BEGIN
    DECLARE @totalPrice  decimal(10,2);

    SELECT @totalPrice = SUM(product.price * order_item.quantity)
    FROM orders
    INNER JOIN order_item ON orders.order_id = order_item.order_id
    INNER JOIN product ON order_item.product_id = product.product_id
    WHERE orders.order_id = @orderID;

    RETURN @totalPrice;
END;
SELECT dbo.CalculateOrderTotalPrice(1221) as total_price; -- Replace 1221 with the desired order ID
go
--creating aother function
CREATE FUNCTION CalculateanotherTotalPriceForOrders (@orderID1 int, @orderID2 int)
RETURNS decimal(10,2)
AS
BEGIN
    DECLARE @totalPrice decimal(10,2);

    SELECT @totalPrice = SUM(product.price * order_item.quantity)
    FROM orders
    INNER JOIN order_item ON orders.order_id = order_item.order_id
    INNER JOIN product ON order_item.product_id = product.product_id
    WHERE orders.order_id IN (@orderID1, @orderID2);

    RETURN @totalPrice;
END;
go
SELECT dbo.CalculateanotherTotalPriceForOrders(1331, 1441) AS TotalPrice;
go
--Built in functions
Select Max(price) as Maxprice from product;
select sum(quantity) as TotalQuantity from order_item;

go

--creating a procedure 1
CREATE PROCEDURE total_price
AS 
BEGIN
    SELECT 
        COUNT(*) AS number_of_products,
        SUM(price) AS total_price
    FROM 
        product;
END;
GO

EXEC total_price;

go

--creating a procedure 2
create procedure total_amount
as 
begin
select 
sum(amount) as total_amount 
from 
payments;
end
execute total_amount;
go

---creating a trigger
create trigger new_trigger on seller
after update as 
select *from seller
update seller set phone_number = '0922222222' where seller_id = 202; 

--droping trigger
drop trigger new_trigger
go
Create trigger update_quantity on order_item 
Instead of update As  
Print ('The quantity of the order_items will not be modified') 
/*In the above code if we update the table order_item it will not work
like update order_item set quantity = 100 where order_id = 1661;*/
update order_item set quantity = 100 where order_id = 1661;

---transaction processing 1
BEGIN TRANSACTION seller_seller;
INSERT INTO seller (seller_id, company_name, phone_number)
VALUES (0208, 'Denim', '0331110909');
UPDATE seller
SET phone_number = '0331141221'
WHERE seller_id = 204;

COMMIT TRANSACTION seller_seller;
select *from seller

---transaction processing 2
begin transaction new_customer
update customer set Email = 'itisme12321@gmail.com' where customer_id = 1040
insert into customer(customer_id,FirstName,LastName,Email)
       values(999,'kidus','kebede','kidusbelete456@gmail.com')
rollback transaction new_customer

select *from customer



go
select *from seller

--creating login and user names

Create login New with password='1221';
Create user Belay for login New ;
grant select ,delete on product to Belay;
revoke update on product from Belay;